GLAM BY ZUNI WEBSITE

Files:
- index.html
- styles.css
- script.js

Verified public Google Maps details used:
- Business name: Glam By Zuni
- Category: Beauty salon
- Address: New, Z Block, Satellite, Block Z Town, Sargodha, 40100, Pakistan
- Phone: +92 347 1205113
- Google rating shown at build time: 5.0 from 9 reviews
- Hours shown at build time: Open 24 hours, Monday-Sunday
- Map coordinates: 32.0653414, 72.7105165

Notes:
- The exact service menu was not available in the public listing. Service cards are written as enquiries and explicitly ask visitors to confirm availability.
- Gallery images are remote Unsplash images used for visual presentation and can be replaced by changing the image URLs in index.html/styles.css.
- WhatsApp links use the public phone number and pre-filled enquiry messages.
- Everything is editable in plain HTML/CSS/JavaScript.
